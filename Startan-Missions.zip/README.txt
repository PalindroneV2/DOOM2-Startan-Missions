Startan Missions is a small 16 map episode.
8 Normal Levels
8 Secret Levels

The normal levels are accessible from the STARTAN HUB.
The secret levels are unlockable. When found and beate, the door to them will unlock in the STARTAN HUB.

1. Works in Progress - Blast through a small factory and industrial street.
2. Volcanic Fortress - Enter a massive Hell Fortress built in a volcano
3. Escape Prohibited - Find your way out of an oppressive and tight techbase fighing space.
4. The Tomb of Id-K'yeth - Delve into the tomb of an ancient demon to fight him.
5. The FOB - Explore a forward operating base that was investigating an underground demonic castle.
6. Silence in the Library - Short experimental stealth level
7. Hot Start - The burning guts of hell with a complimentary anceint fortress.
8. Blacksite - A techbase having a blackout, no comms in or out.
SECRET1. Jamais Vu - A place so familiar yet disimilar.
SECRET2. Raiders - Stop them from stealing it.
SECRET3. Atomic Cul-de-Sac - The steel is much too strong to break these walls.
SECRET4. Blood Sacrifice - Reject your humanity.
SECRET5. Sturme das Schloss - Get psyched.
SECRET6. Diner at the End of the World - The fog rolls in.
SECRET7. Waffenfabrik - Embrace the Trinity and True Power will be Yours.
SECRET8. Ozymandias - Look upon my works ye mighty and despair!

Built for GZDoom using GZDoom 4.12.2
Gameplay mods not recommended. Discouraged even.

Includes several maps from my RAMP participations that have been tweaked.
Custom Enemies, Custom Weapons